﻿#ifndef _BIOSSN_H_
#define _BIOSSN_H_

#ifdef _EXPORTING_BIOSSN
#define BIOSSN_API_DECLSPEC __declspec(dllexport)
#else
#define BIOSSN_API_DECLSPEC __declspec(dllimport)
#endif

#ifndef IN
#define IN
#endif

#ifndef INOUT
#define INOUT
#endif

#ifndef OUT
#define OUT
#endif

#define MAX_BIOS_SN 64


extern "C"
{
    /// <SUMMARY>
    /// 获取BIOS序列号, 需要管理员权限
    /// </SUMMARY>
    /// <PARAM name="buffer" dir="OUT">
    /// 存储序列号
    /// </PARAM>
    /// <RETURNS> 
    /// 成功返回true, 失败返回false
    /// </RETURNS>
    BIOSSN_API_DECLSPEC bool GetBiosSN(OUT char buffer[MAX_BIOS_SN]);

    /// <SUMMARY>
    /// 内部测试函数, 需要管理员权限
    /// </SUMMARY>
    BIOSSN_API_DECLSPEC void InternalTest();
};

#endif